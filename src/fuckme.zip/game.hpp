#ifndef _GAME_H_
#define _GAME_H_

extern int gameState;
extern void doGame();
extern int GM_NIGHT;
extern int GM_BEAR;
extern int GM_BUNNY;
extern int GM_BIRD;
extern int GM_FOX;

#endif