#ifndef _MENU_H_
#define _MENU_H_

extern void doMenu();
extern void restart();

#endif
